#!/bin/bash
NGINX_PATH=$(cd "$(dirname "$0")";pwd)
echo $NGINX_PATH
export LD_LIBRARY_PATH=$NGINX_PATH/../lib:$LD_LIBRARY_PATH
./nginx -p $NGINX_PATH/../ -c conf/nginx.conf
