#ifndef LIBXL_HANDLE_H
#define LIBXL_HANDLE_H

typedef struct tagBookHandle * BookHandle;
typedef struct tagSheetHandle * SheetHandle;
typedef struct tagFormatHandle * FormatHandle;
typedef struct tagFontHandle * FontHandle;
typedef struct tagAutoFilterHandle * AutoFilterHandle;
typedef struct tagFilterColumnHandle * FilterColumnHandle;


#endif
